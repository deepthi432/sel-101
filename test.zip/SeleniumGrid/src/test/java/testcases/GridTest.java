package testcases;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class GridTest {

	public WebDriver driver;
	public DesiredCapabilities cap = new DesiredCapabilities();
	
	
	@Parameters({"browser","url"})
	@Test
	public void doLogin(String browser, String url) throws MalformedURLException, InterruptedException {
		
		if(browser.equals("Chrome")) {
			
			cap.setPlatform(Platform.ANY);
			cap.setBrowserName("Chrome");
			
			ChromeOptions option = new ChromeOptions();
			option.merge(cap);
			
			
		}else if(browser.equals("firefox")) {
			
			
			cap.setPlatform(Platform.ANY);
			cap.setBrowserName("firefox");
			
			FirefoxOptions option = new FirefoxOptions();
			option.merge(cap);
		
		}
		
		
		driver = new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"),cap);
		
		
		driver.get("http://google.com");
		
		driver.findElement(By.name("q")).sendKeys("Hello browser : "+browser);
		
		Thread.sleep(3000);
		
		driver.quit();
	}

}
