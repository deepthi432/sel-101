package com.hello.world.demo.service;

public interface FortuneService {

	
	public String getFortune();
}
