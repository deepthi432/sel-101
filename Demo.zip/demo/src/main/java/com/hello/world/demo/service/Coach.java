package com.hello.world.demo.service;

public interface Coach {

	public String giveWorkout();
	
	public String getFortune();
}
