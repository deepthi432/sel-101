package utilities;

import java.lang.reflect.Method;

import org.testng.annotations.DataProvider;

import base.BaseTest;

public class TestUtil extends BaseTest{

	@DataProvider(name="dp")
	public Object[][] getData(Method m){
		
		String sheetname=m.getName();
		int rowCount=excel.getRowCount(sheetname);
	    int colCount=excel.getColumnCount(sheetname);
	    
	    Object[][] data=new Object[rowCount-1][colCount];
	    
	    for(int rows=2;rows<=rowCount;rows++) {
	    	
	    	for(int cols=0;cols<colCount;cols++) {
	    		
	    		data[rows-2][cols]=excel.getCellData(sheetname, cols, rows);
	    	}
	    }
	    
	    return data;   
		
		
	}
	
	
	
}
