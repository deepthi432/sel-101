package testcases;

import org.testng.annotations.Test;

import base.BaseTest;
import utilities.TestUtil;

public class UserRegTest extends BaseTest{

	@Test(dataProviderClass=TestUtil.class,dataProvider="dp")
	public void doUserReg(String firstname,String lastname) {
		
		System.out.println(firstname+"--------------"+lastname);
		
	}
}
