package extentlisteners;

import java.util.Date;

import org.testng.ISuite;
import org.testng.ISuiteListener;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.Markup;
import com.aventstack.extentreports.markuputils.MarkupHelper;

import utiilities.TestUtil;



public class ExtentListeners implements ITestListener,ISuiteListener {

	
	   static Date d= new Date();
	   static String filename= "Extent_"+d.toString().replace(" ", "_").replace(":", "_")+".html";
	   
	   public static ExtentReports extent=ExtentManager.createInstance(System.getProperty("user.dir")+"/reports/"+ filename);
	
	   public static ExtentTest test;
	
	
		
	
	public void onStart(ISuite suite) {
		// TODO Auto-generated method stub
		
	}

	public void onFinish(ISuite suite) {
		// TODO Auto-generated method stub
		
	}

	public void onTestStart(ITestResult result) {
		test=extent.createTest(result.getClass().getName()+"       @TestCase :    "+result.getMethod().getMethodName());
		
	}

	public void onTestSuccess(ITestResult result) {
		String methodName=result.getMethod().getMethodName();
		String logtext= "<b>"+" TEST CASE: "+methodName.toUpperCase()+" PASSED "+"</b>";
		Markup m=MarkupHelper.createLabel(logtext,ExtentColor.GREEN);
		test.pass(m);
	}

	public void onTestFailure(ITestResult result) {
		
		test.fail(result.getThrowable().getMessage());
		
		TestUtil.captureScreenshot();
		String screenshot=TestUtil.fileName;
		
		test.fail("<b><font color=red>"+"  ScreenShot of Failure "+"</font></b><br>",MediaEntityBuilder.createScreenCaptureFromPath(screenshot).build());
		String methodName=result.getMethod().getMethodName();
		String logtext= "<b>"+" TEST CASE: "+methodName.toUpperCase()+" FAILED "+"</b>";
		Markup m=MarkupHelper.createLabel(logtext,ExtentColor.RED);
		test.fail(m);
		
	}

	public void onTestSkipped(ITestResult result) {
		String methodName=result.getMethod().getMethodName();
		String logtext= "<b>"+" TEST CASE: "+methodName.toUpperCase()+" SKIPPED "+"</b>";
		Markup m=MarkupHelper.createLabel(logtext,ExtentColor.AMBER);
		test.skip(m);
		
	}

	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
		// TODO Auto-generated method stub
		
	}

	public void onStart(ITestContext context) {
		// TODO Auto-generated method stub
		
	}

	public void onFinish(ITestContext context) {
		if(extent!=null) {
			
			extent.flush();
		}
		
	}

	
	
}
