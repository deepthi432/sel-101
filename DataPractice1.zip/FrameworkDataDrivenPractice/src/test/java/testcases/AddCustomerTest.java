package testcases;

import org.openqa.selenium.Alert;
import org.testng.Assert;
import org.testng.annotations.Test;

import base.BaseTest;
import utiilities.TestUtil;

public class AddCustomerTest extends BaseTest{

	@Test(dataProviderClass=TestUtil.class,dataProvider="dp")
	public void addCustomer(String firstname,String lastname,String postcode) {
		
		click("addCustBtn_CSS");
		type("firstName_CSS",firstname);
		type("lastName_CSS",lastname);
		type("postCode_CSS",postcode);
		click("submitAdd_CSS");
	
		Alert alert=driver.switchTo().alert();
		Assert.assertTrue(alert.getText().contains("Customer added successfully"), "Customer not added successfully");
		alert.accept();
		
	}
	
}
