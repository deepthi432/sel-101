package testcases;

import org.testng.Assert;

import base.BaseTest;

public class BankManagerLoginTest extends BaseTest{

	public void bankManagerLogin() {
		
	
		
		click("bmlBtn_CSS");
		Assert.assertTrue(isElementPresent("addCustBtn_CSS"), "Login not successfull");
		
		
	}
	
}
