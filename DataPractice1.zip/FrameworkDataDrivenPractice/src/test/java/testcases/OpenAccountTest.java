package testcases;

import org.openqa.selenium.Alert;
import org.testng.Assert;
import org.testng.annotations.Test;

import base.BaseTest;
import utiilities.TestUtil;

public class OpenAccountTest extends BaseTest{

	@Test(dataProviderClass=TestUtil.class,dataProvider="dp")
	public void openAccount(String customer,String currency) {
		
		click("openActBtn_CSS");
		select("cust_CSS",customer);
		select("currency_CSS",currency);
		click("submitOpen_CSS");
		
		Alert alert=driver.switchTo().alert();
		Assert.assertTrue(alert.getText().contains("Account created successfully"), "Account not created successfully");
		alert.accept();
	}
	
}
