package utiilities;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.annotations.DataProvider;

import base.BaseTest;

public class TestUtil extends BaseTest{

	public static String fileName;
	
	public static void captureScreenshot() {
		
		Date d=new Date();
		fileName=d.toString().replace(":", "_").replace(" ", "_")+".jpg";
		
		File screenshotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		
		try {
			FileUtils.copyFile(screenshotFile, new File("./reports/"+fileName));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	
	@DataProvider(name="dp")
	public Object[][] getData(Method m){
		
		String sheetname=m.getName();
		int rowCount= excel.getRowCount(sheetname);
		int colCount=excel.getColumnCount(sheetname);
		
		Object[][] data=new Object[rowCount-1][colCount]; 
		
		for(int rows=2;rows<=rowCount;rows++) {
			
			for(int cols=0;cols<colCount;cols++) {
				
				data[rows-2][cols]=excel.getCellData(sheetname, cols, rows);
			}
		}
		
		return data;
		
		
	}
	
	
}
