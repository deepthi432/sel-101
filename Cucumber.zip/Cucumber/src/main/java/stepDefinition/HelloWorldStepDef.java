package stepDefinition;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class HelloWorldStepDef {

	private String input;
	
	@Given("I initialize a field with Hello World string")
	public void initialiseHelloWorld() {
		
		input="Hello World";
		
	}
	
	@Then("Print Hello World")
	public void printHelloWorld() {
		
		System.out.println(input);
	}
}
